import java.util.Random;

public class SudokuGenerator {
    public static int[][] generatePuzzle() {
        int[][] board = new int[9][9];
        fillDiagonal(board);
        fillRemaining(board, 0, 3);
        removeDigits(board);
        return board;
    }

    private static void fillDiagonal(int[][] board) {
        for (int i = 0; i < 9; i += 3) {
            fillBox(board, i, i);
        }
    }

    private static boolean fillRemaining(int[][] board, int i, int j) {
        if (j >= 9 && i < 8) {
            i++;
            j = 0;
        }
        if (i >= 9 && j >= 9) {
            return true;
        }
        if (i < 3) {
            if (j < 3) {
                j = 3;
            }
        } else if (i < 6) {
            if (j == (i / 3) * 3) {
                j += 3;
            }
        } else {
            if (j == 6) {
                i++;
                j = 0;
                if (i >= 9) {
                    return true;
                }
            }
        }

        for (int num = 1; num <= 9; num++) {
            if (isSafe(board, i, j, num)) {
                board[i][j] = num;
                if (fillRemaining(board, i, j + 1)) {
                    return true;
                }
                board[i][j] = 0;
            }
        }
        return false;
    }

    private static void fillBox(int[][] board, int row, int col) {
        Random random = new Random();
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                int num;
                do {
                    num = random.nextInt(9) + 1;
                } while (!isSafeInBox(board, row, col, num));
                board[row + i][col + j] = num;
            }
        }
    }

    private static boolean isSafe(int[][] board, int row, int col, int num) {
        return isSafeInRow(board, row, num) && isSafeInCol(board, col, num) && isSafeInBox(board, row - row % 3, col - col % 3, num);
    }

    private static boolean isSafeInRow(int[][] board, int row, int num) {
        for (int col = 0; col < 9; col++) {
            if (board[row][col] == num) {
                return false;
            }
        }
        return true;
    }

    private static boolean isSafeInCol(int[][] board, int col, int num) {
        for (int row = 0; row < 9; row++) {
            if (board[row][col] == num) {
                return false;
            }
        }
        return true;
    }

    private static boolean isSafeInBox(int[][] board, int boxStartRow, int boxStartCol, int num) {
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                if (board[boxStartRow + row][boxStartCol + col] == num) {
                    return false;
                }
            }
        }
        return true;
    }

    private static void removeDigits(int[][] board) {
        Random random = new Random();
        int count = 20; // Number of cells to be removed, can be adjusted
        while (count != 0) {
            int cellId = random.nextInt(81);
            int row = cellId / 9;
            int col = cellId % 9;
            if (board[row][col] != 0) {
                board[row][col] = 0;
                count--;
            }
        }
    }
}

