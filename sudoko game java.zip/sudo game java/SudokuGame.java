public class SudokuGame {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                SudokuGUI gui = new SudokuGUI();
                gui.createAndShowGUI();
            }
        });
    }
}