import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SudokuGUI {
    private JFrame frame;
    private JTextField[][] cells;

    public void createAndShowGUI() {
        frame = new JFrame("Su-Do-Ku Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(9, 9));

        cells = new JTextField[9][9];
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                cells[row][col] = new JTextField();
                cells[row][col].setHorizontalAlignment(JTextField.CENTER);
                frame.add(cells[row][col]);
            }
        }

        JButton generateButton = new JButton("Generate Puzzle");
        generateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int[][] puzzle = SudokuGenerator.generatePuzzle();
                fillPuzzle(puzzle);
            }
        });

        frame.add(generateButton, BorderLayout.SOUTH);

        frame.pack();
        frame.setVisible(true);
    }

    private void fillPuzzle(int[][] puzzle) {
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                if (puzzle[row][col] != 0) {
                    cells[row][col].setText(String.valueOf(puzzle[row][col]));
                    cells[row][col].setEditable(false);
                } else {
                    cells[row][col].setText("");
                    cells[row][col].setEditable(true);
                }
            }
        }
    }
}
